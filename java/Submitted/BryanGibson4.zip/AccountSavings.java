import java.util.Scanner;

public class AccountSavings {

    static double annualInterestRate = 0.0;
    double savingsBalance = 0.0;
    static Scanner input = new Scanner(System.in);

    //constructor
    public AccountSavings (double savingsBalance){

        //checks if balance is negative
        if (savingsBalance < 0.0) {

            throw new IllegalArgumentException("Balance can't be negative.");
        }
        else {

            this.savingsBalance = savingsBalance;
        }

    }

    //calculates and adds monthly interest
    public double calculateMonthlyInterest(double annualInterestRate, double savingsBalance) {

        savingsBalance += (savingsBalance * annualInterestRate) / 12;
        return savingsBalance;

    }//end method

    //set interest rate
    static double modifyInterestRate(double annualInterestRate, Scanner input) {

        System.out.println("Please enter new Interest Rate:");
        annualInterestRate = input.nextDouble();

        //checks if InterestRate is within parameters
        if (annualInterestRate < 0.0 || annualInterestRate > 1.0) {

            throw new IllegalArgumentException("Interest Rate must be >= 0.0 and <= 1.0");

        }

        return annualInterestRate;
    }//end method

    //return balance as string
    public String toString (double savingsBalance){

        //returns savingsBalance as string, formatted to 2 decimal places
        return String.format("%.2f", savingsBalance);
    }//end method
}
