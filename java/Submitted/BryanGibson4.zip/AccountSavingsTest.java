public class AccountSavingsTest {

    public static void main (String [] args){

        //create objects
        AccountSavings account1 = new AccountSavings(2000);
        AccountSavings account2 = new AccountSavings(3000);
        AccountSavings.annualInterestRate = AccountSavings.modifyInterestRate(AccountSavings.annualInterestRate,
                AccountSavings.input);

        //initial formatting
        System.out.println("Monthly balances for one year at " + AccountSavings.annualInterestRate);
        System.out.println("Balances:");
        System.out.printf("%20s  %7s%n", "Saver 1", "Saver 2");
        System.out.printf("Base %15.2f  %7.2f%n", account1.savingsBalance, account2.savingsBalance);

        //loops to calculate interest and add it to balance for each month
        for (int i=1; i <= 12; i++){

            System.out.printf("%s %d: %11s  %-9s%n", "Month", i, account1.toString(account1.calculateMonthlyInterest
                    (AccountSavings.annualInterestRate, account1.savingsBalance)), account2.toString
                    (account2.calculateMonthlyInterest(AccountSavings.annualInterestRate, account2.savingsBalance)));

            //update balance with new interest
            account1.savingsBalance = account1.calculateMonthlyInterest(AccountSavings.annualInterestRate, account1.savingsBalance);
            account2.savingsBalance = account2.calculateMonthlyInterest(AccountSavings.annualInterestRate, account2.savingsBalance);
        }
    }
}
